export const productsCollection = "products";
export const cartsCollection = "carts";